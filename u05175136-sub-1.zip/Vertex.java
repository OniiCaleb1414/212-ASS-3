import java.util.ArrayList;

enum VertexType {
    MINER, SMELTER, CONSTRUCTOR, ASSEMBLER, MANUFACTURER, REFINERY, GENERATOR, UNDEFINED
}

public class Vertex {
    ArrayList<Edge> edges = new ArrayList<>();
    static int globalCounter = 1;
    int counter = globalCounter++;
    VertexType type;

    public Vertex(String type) {
        this.counter = globalCounter++;
        this.edges = new ArrayList<>();
        try {
            this.type = VertexType.valueOf(type.toUpperCase());
        } catch (IllegalArgumentException e) {
            this.type = VertexType.UNDEFINED;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Vertex)) return false;
        Vertex other = (Vertex) obj;
        return this.type == other.type;
    }

    @Override
    public String toString() {
        String image = "";
        switch (type) {
            case MINER:
                image = "miner";
                break;
            case SMELTER:
                image = "smelter";
                break;
            case CONSTRUCTOR:
                image = "constructor";
                break;
            case ASSEMBLER:
                image = "assembler";
                break;
            case MANUFACTURER:
                image = "manufacturer";
                break;
            case REFINERY:
                image = "refinery";
                break;
            case GENERATOR:
                image = "generator";
                break;
            default:
                image = "undefined";
        }

        return "(" + counter + " " + image + ")";
    }

}